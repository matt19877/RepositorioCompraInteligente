-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 15-09-2013 a las 14:58:43
-- Versión del servidor: 5.5.20
-- Versión de PHP: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `comprainteligente`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE IF NOT EXISTS `categoria` (
  `pu1_id` int(11) NOT NULL,
  `pu2_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `pu3_nombre` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`pu1_id`, `pu2_id`, `cat_id`, `pu3_nombre`) VALUES
(1, 1, 1, 'Alfa Romeo'),
(1, 1, 2, 'BMW'),
(1, 2, 1, 'Alfa Romeo'),
(1, 2, 2, 'BMW'),
(2, 1, 1, 'Alquiler'),
(2, 1, 2, 'Venta'),
(2, 2, 1, 'Alquiler'),
(2, 2, 2, 'Alquiler Temporario'),
(3, 1, 1, 'Cosmetologia'),
(3, 1, 2, 'Depilación'),
(3, 2, 1, 'Apoyo Escolar y Universitario'),
(3, 2, 2, 'Artes Plásticas'),
(4, 1, 1, 'Accesorios para cuatriciclos y motos'),
(4, 1, 2, 'Accesorios Náuticos'),
(4, 2, 1, 'Aves'),
(4, 2, 2, 'Caballos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicar1`
--

CREATE TABLE IF NOT EXISTS `publicar1` (
  `pu1_id` int(11) NOT NULL AUTO_INCREMENT,
  `pu1_nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`pu1_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `publicar1`
--

INSERT INTO `publicar1` (`pu1_id`, `pu1_nombre`) VALUES
(1, 'Vehículos'),
(2, 'Inmuebles'),
(3, 'Servicios'),
(4, 'Productos y Otros');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicar2`
--

CREATE TABLE IF NOT EXISTS `publicar2` (
  `pu1_id` int(11) NOT NULL,
  `pu2_id` int(11) NOT NULL,
  `pu2_nombre` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `publicar2`
--

INSERT INTO `publicar2` (`pu1_id`, `pu2_id`, `pu2_nombre`) VALUES
(1, 1, 'Autos de Colección'),
(1, 2, 'Autos y Camionetas'),
(2, 1, 'Campos'),
(2, 2, 'Casas'),
(3, 1, 'Belleza y Cuidado Personal'),
(3, 2, 'Clases y Capacitaciones'),
(4, 1, 'Accesorios para Vehículos'),
(4, 2, 'Animales y Mascotas');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
